<?php

/*Template Name: Gallery*/

?>

<?php get_header();?>


<div class="container">

<!-- Gallery -->
    <section class="main-wrapper">   


        <div id="albums">        

            <?php 
                // the album
                $the_gallery = new WP_Query( array(
                    'category_name' => 'Gallery',
                )); 
            ?>

        <?php if ( $the_gallery->have_posts() ) : ?>
        <?php while ( $the_gallery->have_posts() ) : $the_gallery->the_post(); ?>

        <?php 
            foreach ( $the_gallery as $object)
        ?>

            <div class="album-wrap">
                <div class="album-photo">
                    <?php echo get_the_post_thumbnail();?>
                    <a class="album-title"> <?php echo the_title(); ?></a>
                </div>
            </div>

            <?php endwhile; ?>
            <?php wp_reset_postdata(); ?>

            <?php else : ?>
            <p><?php __('No gallery content'); ?></p>
            <?php endif; ?>

        </div>

    </section>

</div>


<?php get_footer();?>

