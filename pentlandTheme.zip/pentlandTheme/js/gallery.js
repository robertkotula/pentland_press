(function($) {

    $('.gallery-image-wrapper img').on('click', function(){
        currentImage = $(this).index();
        changeImage(currentImage);
        showOverlay();
    });
    
    $('.gallery-overlay, .gallery-overlay-nav-close').on('click', function(){
        $('.gallery-overlay').hide();
    });
    
    function showOverlay(){
        $('.gallery-overlay').show();
    }
    
    function closeOverlay(){
        $('.gallery-overlay').hide();
    }
    
    function changeImage(){
        $('.gallery-overlay .gallery-overlay-image img').attr('src', $('.gallery-image-wrapper img').eq(currentImage).attr('src'));
    }
    
    $('.gallery-overlay-nav-next').on('click', function(e){
        e.stopPropagation();
        if(currentImage + 1){
            currentImage++;
            changeImage();
        }    
    });
    
    $('.gallery-overlay-nav-prev').on('click', function(e){
        e.stopPropagation();
        if(currentImage - 1 >= 0){
            currentImage--;
            changeImage();
        }    
    });
    
})(jQuery);

