<?php get_header();?>
<div class="container">
    <section class="main-wrapper">
        <div class="gallery-image-wrapper">

            <?php if( have_posts() ): while( have_posts() ): the_post();
            /*If there are posts and while there are posts, show post*/
            ?>

                <?php the_content();?>

            <?php endwhile; else: endif;?>
        </div>
    </section>
</div>

<div class="gallery-overlay">
    <button aria-label="Close" class="gallery-overlay-nav gallery-overlay-nav-close" type="button"><i class="fas fa-times"></i></button>
    <button aria-label="prev" class="gallery-overlay-nav gallery-overlay-nav-prev" type="button"><i class="fas fa-chevron-left"></i></button>
    <button aria-label="next" class="gallery-overlay-nav gallery-overlay-nav-next" type="button"><i class="fas fa-chevron-right"></i></button>
    <div class="gallery-overlay-image">
        <img src="" alt="image">
    </div>
</div>

<?php get_footer();?>