<?php

// load style and js
function add_theme_scripts() {
    wp_enqueue_style( 'style', get_stylesheet_uri() );
   
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), false, 'all');

    wp_enqueue_style( 'header', get_template_directory_uri() . '/css/header.css', array(), false, 'all');

    wp_enqueue_style( 'main', get_template_directory_uri() . '/css/main.css', array(), false, 'all');

    wp_enqueue_style( 'gallery', get_template_directory_uri() . '/css/gallery.css', array(), false, 'all');

    wp_enqueue_style( 'media_queries', get_template_directory_uri() . '/css/media_queries.css', array(), false, 'all');

    wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/fontawesome.css', array(), false, 'all');
   
    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array ( 'jquery' ), false, true);

    wp_enqueue_script( 'gallery', get_template_directory_uri() . '/js/gallery.js', array (), false, true);

    
   
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
      wp_enqueue_script( 'comment-reply' );
    }
}
  add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );



// Theme Options 
add_theme_support('menus');
add_theme_support( 'post-thumbnails' );
add_theme_support('custom-logo', array('header-text' => array('site-title', 'site-description')));
add_theme_support('widgets');

// Register Nav Walker class_alias 
require_once('wp_bootstrap_navwalker.php');


// Menus
register_nav_menus(

  array(
    'main-menu' => 'Main Menu Location',
    'mobile-menu' => 'Mobile Menu Location'
  )

);

add_theme_support( 'post-formats', array('gallery', 'link'));

//Custom image sizes

add_image_size('blog-large', false);
add_image_size('blog-medium', 800, 400, true);
add_image_size('blog-small', 300, 200, true);


//Register sidebars
function my_sidebars()
{
  register_sidebar(
   array(
     'name' => 'Page Sidebar',
     'id' => 'page-sidebar',
     'before_title' => '<h4 class="widget-title">',
     'after_title' => '</h4>',
   ) 
   );
   register_sidebar(
    array(
      'name' => 'Blog Sidebar',
      'id' => 'blog-sidebar',
      'before_title' => '<h4 class="widget-title">',
      'after_title' => '</h4>',
    ) 
    );
}
add_action('widgets_init', 'my_sidebars');


//Add custom post type & assign categories to it
function my_post_type()
{
  $args = array(
    'labels' => array('name' => 'Gallery', 'singular_name' => 'Gallery'),
    'hierarchical' => true,
    'public' => true,
    'has_archive' => true,
    'supports' => array('title', 'editor', 'thumbnail'),
    'menu_icon' => 'dashicons-images-alt2'
  );


  register_post_type('gallery', $args);

}
add_action('init', 'my_post_type');


function my_taxonomy()
{

  $args = array(
    'labels' => array('name' => 'Albums', 'singular_name' => 'Album'),
    'hierarchical' => true,
    'public' => true,
  );

  register_taxonomy('albums', array('gallery'), $args);

}
add_action('init', 'my_taxonomy');




//active class in nav bar

add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);

function special_nav_class ($classes, $item) {
  if (in_array('current-menu-item', $classes) ){
    $classes[] = 'active ';
  }
  return $classes;
}

//a link to gallery thumbnail

function wpb_autolink_featured_images( $html, $post_id, $post_image_id ) {
  $html = '<a href="' . get_permalink( $post_id ) . '" title="' . esc_attr( get_the_title( $post_id ) ) . '">' . $html . '</a>';
  return $html;
}
add_filter( 'post_thumbnail_html', 'wpb_autolink_featured_images', 10, 3 );

// replace <p> with <img>
function filter_ptags_on_images($content) {
  $content = preg_replace('/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content);
  return preg_replace('/<p>\s*(<iframe .*>*.<\/iframe>)\s*<\/p>/iU', '\1', $content);
}
add_filter('acf_the_content', 'filter_ptags_on_images');
add_filter('the_content', 'filter_ptags_on_images');


