<section class="main-wrapper">   
    <div id="albums">  
        <?php if( have_posts() ): while( have_posts() ): the_post();
        /*If there are posts and while there are posts, show post*/
        ?>

            <?php if(has_post_thumbnail()):?>   
                    
                <div class="album-wrap">
                        <div class="album-photo">
                            <?php echo get_the_post_thumbnail();?>
                            <a class="album-title"> <?php echo the_title(); ?></a>
                        </div>
                    </div>

            <?php endif;?>


        <?php endwhile; else: endif;?>
    </div>
</section>